# Grow Smart - Digital Marketplace and Learning Hub for Farmers

## Overview

Grow Smart is a comprehensive web application designed to serve as a digital marketplace and learning hub for farmers in India. The platform connects farmers with suppliers, provides educational resources, and offers advanced tools to support sustainable farming practices.

## Features

### Marketplace Module
- Product listings from Indian suppliers
- Advanced filtering and search functionality
- Shopping cart and checkout system
- User authentication and profile management
- Order tracking and history

### Learning Resources
- Articles and guides on sustainable farming
- Video tutorials on farming techniques
- Category-based organization of content
- Bookmarking for offline access

### Advanced Features
- AI-powered product and content recommendations
- Multilingual chatbot support (English, Hindi, Gujarati)
- QR code generation and scanning for product information
- Soil health diagnostic tool with personalized recommendations
- Weather integration with forecasting
- Offline capabilities with content caching
- SMS alerts for important notifications

### Additional Modules
- Community forum for farmer discussions
- Multilingual support throughout the application

## Technology Stack

### Frontend
- React.js for UI components
- React Router for navigation
- Tailwind CSS for styling and responsive design
- Context API for state management

### Backend
- Node.js with Express.js framework
- MongoDB for database storage
- JWT for authentication
- RESTful API architecture

### Advanced Features Implementation
- AI recommendations using collaborative and content-based filtering
- Service workers for offline functionality
- Integration with weather APIs
- QR code generation and processing

## Getting Started

### Prerequisites
- Node.js (v14.0.0 or higher)
- MongoDB (v4.4 or higher)
- npm (v6.0.0 or higher)

### Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/grow-smart.git
cd grow-smart
```

2. Install backend dependencies:
```
cd backend
npm install
```

3. Install frontend dependencies:
```
cd ../frontend
npm install
```

4. Create a `.env` file in the backend directory with the following variables:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/growsmart
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
```

5. Start the backend server:
```
cd ../backend
npm start
```

6. Start the frontend development server:
```
cd ../frontend
npm start
```

7. Access the application at `http://localhost:3000`

## Project Structure

```
grow-smart/
├── frontend/                  # React frontend application
│   ├── public/                # Static files
│   ├── src/                   # Source files
│   │   ├── components/        # React components
│   │   │   ├── common/        # Common UI components
│   │   │   ├── marketplace/   # Marketplace components
│   │   │   ├── learning/      # Learning resources components
│   │   │   └── features/      # Advanced features components
│   │   ├── context/           # React context providers
│   │   ├── pages/             # Page components
│   │   ├── utils/             # Utility functions
│   │   ├── App.js             # Main App component
│   │   └── index.js           # Entry point
│   └── tests/                 # Frontend tests
├── backend/                   # Node.js backend application
│   ├── src/                   # Source files
│   │   ├── config/            # Configuration files
│   │   ├── controllers/       # Request handlers
│   │   ├── middleware/        # Express middleware
│   │   ├── models/            # MongoDB models
│   │   ├── routes/            # API routes
│   │   ├── utils/             # Utility functions
│   │   └── server.js          # Server entry point
│   └── tests/                 # Backend tests
└── e2e-tests/                 # End-to-end tests
```

## API Documentation

The backend provides a RESTful API with the following endpoints:

### Authentication

- `POST /api/users` - Register a new user
- `POST /api/users/login` - Authenticate user and get token
- `GET /api/users/profile` - Get user profile (protected)
- `PUT /api/users/profile` - Update user profile (protected)

### Products

- `GET /api/products` - Get all products (supports filtering)
- `GET /api/products/:id` - Get single product
- `POST /api/products` - Create a product (admin only)
- `PUT /api/products/:id` - Update a product (admin only)
- `DELETE /api/products/:id` - Delete a product (admin only)
- `POST /api/products/:id/reviews` - Create product review (protected)
- `GET /api/products/top` - Get top rated products
- `GET /api/products/supplier/:supplier` - Get products by supplier

### Orders

- `POST /api/orders` - Create new order (protected)
- `GET /api/orders/:id` - Get order by ID (protected)
- `PUT /api/orders/:id/pay` - Update order to paid (protected)
- `GET /api/orders/myorders` - Get logged in user orders (protected)
- `GET /api/orders` - Get all orders (admin only)
- `PUT /api/orders/:id/deliver` - Update order to delivered (admin only)

### Articles

- `GET /api/articles` - Get all articles (supports filtering)
- `GET /api/articles/:id` - Get single article
- `POST /api/articles` - Create an article (admin only)
- `PUT /api/articles/:id` - Update an article (admin only)
- `DELETE /api/articles/:id` - Delete an article (admin only)
- `GET /api/articles/category/:category` - Get articles by category

### Videos

- `GET /api/videos` - Get all videos (supports filtering)
- `GET /api/videos/:id` - Get single video
- `POST /api/videos` - Create a video (admin only)
- `PUT /api/videos/:id` - Update a video (admin only)
- `DELETE /api/videos/:id` - Delete a video (admin only)
- `GET /api/videos/category/:category` - Get videos by category
- `GET /api/videos/channel/:channelName` - Get videos by channel

### Forum

- `GET /api/forum` - Get all forum posts
- `GET /api/forum/:id` - Get single forum post
- `POST /api/forum` - Create a forum post (protected)
- `PUT /api/forum/:id` - Update a forum post (protected)
- `DELETE /api/forum/:id` - Delete a forum post (protected)
- `POST /api/forum/:id/comments` - Add comment to forum post (protected)
- `PUT /api/forum/:id/like` - Like a forum post (protected)

### Advanced Features

#### Recommendations
- `GET /api/recommendations/products` - Get product recommendations (protected)
- `GET /api/recommendations/content` - Get content recommendations (protected)
- `POST /api/recommendations/personalized` - Get personalized recommendations (protected)

#### Chatbot
- `POST /api/chatbot/message` - Get chatbot response

#### QR Code
- `GET /api/qrcode/product/:id` - Generate QR code data for a product
- `POST /api/qrcode/scan` - Process scanned QR code data

#### Soil Health
- `POST /api/soil-health/analyze` - Analyze soil health and provide recommendations

#### Weather
- `GET /api/weather/:location` - Get weather data by location
- `GET /api/weather/forecast/:location` - Get forecast data by location

#### Offline
- `POST /api/offline/register` - Register device for offline access (protected)
- `GET /api/offline/content` - Get content for offline caching (protected)
- `POST /api/offline/sms-alert` - Send SMS alert (admin only)

## Testing

The application includes comprehensive test suites:

### Backend Tests
- API route tests using Jest and Supertest
- Model validation tests
- Authentication middleware tests

### Frontend Tests
- Component tests using React Testing Library
- Context provider tests
- Utility function tests

### Integration Tests
- Frontend-backend interaction tests
- Data flow tests
- Error handling tests

### End-to-End Tests
- Complete user journey tests using Selenium WebDriver
- Cross-browser compatibility tests

Run tests with the following commands:

```
# Backend tests
cd backend
npm test

# Frontend tests
cd frontend
npm test

# End-to-end tests
cd e2e-tests
npm test
```

## Deployment

### Production Build

1. Create production build for frontend:
```
cd frontend
npm run build
```

2. Set environment variables for production:
```
NODE_ENV=production
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_production_jwt_secret
```

3. Start the production server:
```
cd backend
npm start
```

### Deployment Options

- **Heroku**: Use the Procfile included in the repository
- **AWS**: Deploy using Elastic Beanstalk or EC2
- **Docker**: Containerize using the provided Dockerfile

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- All the Indian farmers who provided valuable feedback during development
- Agricultural universities for content and domain expertise
- Open-source community for tools and libraries used in this project
