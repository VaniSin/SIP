# API Documentation - Grow Smart

This document provides detailed information about the RESTful API endpoints available in the Grow Smart application.

## Base URL

All API endpoints are relative to the base URL:

```
https://api.growsmart.com/api
```

For local development:

```
http://localhost:5000/api
```

## Authentication

Most endpoints require authentication using JSON Web Tokens (JWT).

### How to Authenticate

1. Obtain a JWT token by logging in or registering
2. Include the token in the Authorization header of your requests:

```
Authorization: Bearer <your_jwt_token>
```

### Authentication Endpoints

#### Register a New User

```
POST /users
```

Request body:
```json
{
  "name": "Farmer Name",
  "email": "farmer@example.com",
  "password": "securepassword",
  "phone": "1234567890",
  "preferredLanguage": "english"
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ca",
  "name": "Farmer Name",
  "email": "farmer@example.com",
  "role": "user",
  "preferredLanguage": "english",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### Login User

```
POST /users/login
```

Request body:
```json
{
  "email": "farmer@example.com",
  "password": "securepassword"
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ca",
  "name": "Farmer Name",
  "email": "farmer@example.com",
  "role": "user",
  "preferredLanguage": "english",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

## User Endpoints

### Get User Profile

```
GET /users/profile
```

Authentication: Required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ca",
  "name": "Farmer Name",
  "email": "farmer@example.com",
  "phone": "1234567890",
  "role": "user",
  "address": {
    "street": "123 Farm Road",
    "city": "Farmville",
    "postalCode": "123456",
    "state": "Gujarat"
  },
  "preferredLanguage": "english",
  "bookmarks": [
    {
      "_id": "60d0fe4f5311236168a109cb",
      "type": "article",
      "itemId": "60d0fe4f5311236168a109cc",
      "itemType": "organic-farming",
      "addedAt": "2025-04-15T10:30:00.000Z"
    }
  ]
}
```

### Update User Profile

```
PUT /users/profile
```

Authentication: Required

Request body:
```json
{
  "name": "Updated Name",
  "email": "updated@example.com",
  "phone": "9876543210",
  "preferredLanguage": "hindi",
  "address": {
    "street": "456 New Farm Road",
    "city": "New Farmville",
    "postalCode": "654321",
    "state": "Maharashtra"
  },
  "password": "newpassword"
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ca",
  "name": "Updated Name",
  "email": "updated@example.com",
  "phone": "9876543210",
  "role": "user",
  "address": {
    "street": "456 New Farm Road",
    "city": "New Farmville",
    "postalCode": "654321",
    "state": "Maharashtra"
  },
  "preferredLanguage": "hindi",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### Add Bookmark

```
POST /users/bookmarks
```

Authentication: Required

Request body:
```json
{
  "type": "article",
  "itemId": "60d0fe4f5311236168a109cc",
  "itemType": "organic-farming"
}
```

Response:
```json
{
  "message": "Bookmark added successfully",
  "bookmarks": [
    {
      "_id": "60d0fe4f5311236168a109cb",
      "type": "article",
      "itemId": "60d0fe4f5311236168a109cc",
      "itemType": "organic-farming",
      "addedAt": "2025-04-15T10:30:00.000Z"
    }
  ]
}
```

### Remove Bookmark

```
DELETE /users/bookmarks/:id
```

Authentication: Required

Response:
```json
{
  "message": "Bookmark removed successfully",
  "bookmarks": []
}
```

## Product Endpoints

### Get All Products

```
GET /products
```

Authentication: Not required

Query parameters:
- `category` - Filter by product category
- `supplier` - Filter by supplier name
- `brand` - Filter by brand name
- `keyword` - Search in product name
- `min` - Minimum price
- `max` - Maximum price

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109cd",
    "name": "Organic Fertilizer",
    "description": "High-quality organic fertilizer for all crops",
    "price": 499,
    "category": "fertilizers",
    "brand": "EcoGrow",
    "supplier": "Agrimart",
    "supplierLink": "https://agrimart.com",
    "imageUrl": "https://example.com/fertilizer.jpg",
    "stock": 100,
    "rating": 4.5,
    "numReviews": 12,
    "reviews": [
      {
        "name": "Farmer Name",
        "rating": 5,
        "comment": "Excellent product, improved my crop yield.",
        "user": "60d0fe4f5311236168a109ca"
      }
    ],
    "createdAt": "2025-03-15T10:30:00.000Z",
    "updatedAt": "2025-04-10T15:45:00.000Z"
  }
]
```

### Get Product by ID

```
GET /products/:id
```

Authentication: Not required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109cd",
  "name": "Organic Fertilizer",
  "description": "High-quality organic fertilizer for all crops",
  "price": 499,
  "category": "fertilizers",
  "brand": "EcoGrow",
  "supplier": "Agrimart",
  "supplierLink": "https://agrimart.com",
  "imageUrl": "https://example.com/fertilizer.jpg",
  "stock": 100,
  "rating": 4.5,
  "numReviews": 12,
  "reviews": [
    {
      "name": "Farmer Name",
      "rating": 5,
      "comment": "Excellent product, improved my crop yield.",
      "user": "60d0fe4f5311236168a109ca"
    }
  ],
  "createdAt": "2025-03-15T10:30:00.000Z",
  "updatedAt": "2025-04-10T15:45:00.000Z"
}
```

### Create Product Review

```
POST /products/:id/reviews
```

Authentication: Required

Request body:
```json
{
  "rating": 5,
  "comment": "Excellent product, improved my crop yield."
}
```

Response:
```json
{
  "message": "Review added"
}
```

### Get Top Products

```
GET /products/top
```

Authentication: Not required

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109cd",
    "name": "Organic Fertilizer",
    "price": 499,
    "imageUrl": "https://example.com/fertilizer.jpg",
    "rating": 4.5,
    "numReviews": 12
  }
]
```

## Order Endpoints

### Create New Order

```
POST /orders
```

Authentication: Required

Request body:
```json
{
  "orderItems": [
    {
      "name": "Organic Fertilizer",
      "qty": 2,
      "image": "https://example.com/fertilizer.jpg",
      "price": 499,
      "product": "60d0fe4f5311236168a109cd"
    }
  ],
  "shippingAddress": {
    "address": "123 Farm Road",
    "city": "Farmville",
    "postalCode": "123456",
    "state": "Gujarat"
  },
  "paymentMethod": "UPI",
  "itemsPrice": 998,
  "taxPrice": 100,
  "shippingPrice": 50,
  "totalPrice": 1148
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ce",
  "user": "60d0fe4f5311236168a109ca",
  "orderItems": [
    {
      "name": "Organic Fertilizer",
      "qty": 2,
      "image": "https://example.com/fertilizer.jpg",
      "price": 499,
      "product": "60d0fe4f5311236168a109cd"
    }
  ],
  "shippingAddress": {
    "address": "123 Farm Road",
    "city": "Farmville",
    "postalCode": "123456",
    "state": "Gujarat"
  },
  "paymentMethod": "UPI",
  "itemsPrice": 998,
  "taxPrice": 100,
  "shippingPrice": 50,
  "totalPrice": 1148,
  "isPaid": false,
  "isDelivered": false,
  "createdAt": "2025-04-15T10:30:00.000Z",
  "updatedAt": "2025-04-15T10:30:00.000Z"
}
```

### Get Order by ID

```
GET /orders/:id
```

Authentication: Required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109ce",
  "user": {
    "_id": "60d0fe4f5311236168a109ca",
    "name": "Farmer Name",
    "email": "farmer@example.com"
  },
  "orderItems": [
    {
      "name": "Organic Fertilizer",
      "qty": 2,
      "image": "https://example.com/fertilizer.jpg",
      "price": 499,
      "product": "60d0fe4f5311236168a109cd"
    }
  ],
  "shippingAddress": {
    "address": "123 Farm Road",
    "city": "Farmville",
    "postalCode": "123456",
    "state": "Gujarat"
  },
  "paymentMethod": "UPI",
  "itemsPrice": 998,
  "taxPrice": 100,
  "shippingPrice": 50,
  "totalPrice": 1148,
  "isPaid": false,
  "isDelivered": false,
  "createdAt": "2025-04-15T10:30:00.000Z",
  "updatedAt": "2025-04-15T10:30:00.000Z"
}
```

### Get My Orders

```
GET /orders/myorders
```

Authentication: Required

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109ce",
    "user": "60d0fe4f5311236168a109ca",
    "orderItems": [
      {
        "name": "Organic Fertilizer",
        "qty": 2,
        "image": "https://example.com/fertilizer.jpg",
        "price": 499,
        "product": "60d0fe4f5311236168a109cd"
      }
    ],
    "totalPrice": 1148,
    "isPaid": false,
    "isDelivered": false,
    "createdAt": "2025-04-15T10:30:00.000Z"
  }
]
```

## Article Endpoints

### Get All Articles

```
GET /articles
```

Authentication: Not required

Query parameters:
- `category` - Filter by article category
- `source` - Filter by source name
- `keyword` - Search in title, content, or summary

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109cf",
    "title": "Sustainable Farming Practices",
    "content": "Detailed content about sustainable farming practices...",
    "summary": "A guide to implementing sustainable farming practices in India",
    "source": {
      "name": "Agricultural University",
      "url": "https://agri-university.edu"
    },
    "category": "sustainable-farming",
    "imageUrl": "https://example.com/sustainable-farming.jpg",
    "tags": ["sustainable", "organic", "farming"],
    "createdAt": "2025-03-10T08:15:00.000Z",
    "updatedAt": "2025-03-10T08:15:00.000Z"
  }
]
```

### Get Article by ID

```
GET /articles/:id
```

Authentication: Not required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109cf",
  "title": "Sustainable Farming Practices",
  "content": "Detailed content about sustainable farming practices...",
  "summary": "A guide to implementing sustainable farming practices in India",
  "source": {
    "name": "Agricultural University",
    "url": "https://agri-university.edu"
  },
  "category": "sustainable-farming",
  "imageUrl": "https://example.com/sustainable-farming.jpg",
  "tags": ["sustainable", "organic", "farming"],
  "createdAt": "2025-03-10T08:15:00.000Z",
  "updatedAt": "2025-03-10T08:15:00.000Z"
}
```

### Get Articles by Category

```
GET /articles/category/:category
```

Authentication: Not required

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109cf",
    "title": "Sustainable Farming Practices",
    "summary": "A guide to implementing sustainable farming practices in India",
    "category": "sustainable-farming",
    "imageUrl": "https://example.com/sustainable-farming.jpg",
    "tags": ["sustainable", "organic", "farming"],
    "createdAt": "2025-03-10T08:15:00.000Z"
  }
]
```

## Video Endpoints

### Get All Videos

```
GET /videos
```

Authentication: Not required

Query parameters:
- `category` - Filter by video category
- `channel` - Filter by channel name
- `keyword` - Search in title or description

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109d0",
    "title": "Drip Irrigation Techniques",
    "description": "Learn about modern drip irrigation techniques for water conservation",
    "youtubeId": "abc123xyz",
    "channelName": "Farming Experts",
    "channelUrl": "https://youtube.com/c/farmingexperts",
    "category": "irrigation",
    "thumbnailUrl": "https://example.com/drip-irrigation.jpg",
    "tags": ["irrigation", "water-conservation", "techniques"],
    "duration": "15:30",
    "createdAt": "2025-02-20T14:25:00.000Z",
    "updatedAt": "2025-02-20T14:25:00.000Z"
  }
]
```

### Get Video by ID

```
GET /videos/:id
```

Authentication: Not required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109d0",
  "title": "Drip Irrigation Techniques",
  "description": "Learn about modern drip irrigation techniques for water conservation",
  "youtubeId": "abc123xyz",
  "channelName": "Farming Experts",
  "channelUrl": "https://youtube.com/c/farmingexperts",
  "category": "irrigation",
  "thumbnailUrl": "https://example.com/drip-irrigation.jpg",
  "tags": ["irrigation", "water-conservation", "techniques"],
  "duration": "15:30",
  "createdAt": "2025-02-20T14:25:00.000Z",
  "updatedAt": "2025-02-20T14:25:00.000Z"
}
```

### Get Videos by Category

```
GET /videos/category/:category
```

Authentication: Not required

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109d0",
    "title": "Drip Irrigation Techniques",
    "description": "Learn about modern drip irrigation techniques for water conservation",
    "youtubeId": "abc123xyz",
    "channelName": "Farming Experts",
    "thumbnailUrl": "https://example.com/drip-irrigation.jpg",
    "duration": "15:30",
    "createdAt": "2025-02-20T14:25:00.000Z"
  }
]
```

## Forum Endpoints

### Get All Forum Posts

```
GET /forum
```

Authentication: Not required

Response:
```json
[
  {
    "_id": "60d0fe4f5311236168a109d1",
    "title": "Best practices for organic pest control?",
    "content": "I'm looking for effective organic methods to control pests in my vegetable garden...",
    "author": {
      "_id": "60d0fe4f5311236168a109ca",
      "name": "Farmer Name"
    },
    "likes": 15,
    "comments": [
      {
        "_id": "60d0fe4f5311236168a109d2",
        "content": "Neem oil works great for most pests...",
        "author": {
          "_id": "60d0fe4f5311236168a109d3",
          "name": "OrganicGuru"
        },
        "date": "2025-04-11T09:45:00.000Z"
      }
    ],
    "tags": ["pest-control", "organic", "vegetables"],
    "createdAt": "2025-04-10T15:30:00.000Z"
  }
]
```

### Get Forum Post by ID

```
GET /forum/:id
```

Authentication: Not required

Response:
```json
{
  "_id": "60d0fe4f5311236168a109d1",
  "title": "Best practices for organic pest control?",
  "content": "I'm looking for effective organic methods to control pests in my vegetable garden...",
  "author": {
    "_id": "60d0fe4f5311236168a109ca",
    "name": "Farmer Name"
  },
  "likes": 15,
  "comments": [
    {
      "_id": "60d0fe4f5311236168a109d2",
      "content": "Neem oil works great for most pests...",
      "author": {
        "_id": "60d0fe4f5311236168a109d3",
        "name": "OrganicGuru"
      },
      "date": "2025-04-11T09:45:00.000Z"
    }
  ],
  "tags": ["pest-control", "organic", "vegetables"],
  "createdAt": "2025-04-10T15:30:00.000Z"
}
```

### Create Forum Post

```
POST /forum
```

Authentication: Required

Request body:
```json
{
  "title": "Irrigation system recommendations for 5-acre farm",
  "content": "I need to set up an efficient irrigation system for my 5-acre farm in Gujarat...",
  "tags": ["irrigation", "water-management", "farm-setup"]
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109d4",
  "title": "Irrigation system recommendations for 5-acre farm",
  "content": "I need to set up an efficient irrigation system for my 5-acre farm in Gujarat...",
  "author": {
    "_id": "60d0fe4f5311236168a109ca",
    "name": "Farmer Name"
  },
  "likes": 0,
  "comments": [],
  "tags": ["irrigation", "water-management", "farm-setup"],
  "createdAt": "2025-04-15T10:30:00.000Z"
}
```

### Add Comment to Forum Post

```
POST /forum/:id/comments
```

Authentication: Required

Request body:
```json
{
  "content": "Drip irrigation would be your best bet for water efficiency..."
}
```

Response:
```json
{
  "_id": "60d0fe4f5311236168a109d1",
  "title": "Irrigation system recommendations for 5-acre farm",
  "comments": [
    {
      "_id": "60d0fe4f5311236168a109d5",
      "content": "Drip irrigation would be your best bet for water efficiency...",
      "author": {
        "_id": "60d0fe4f5311236168a109ca",
        "name": "Farmer Name"
      },
      "date": "2025-04-15T10:45:00.000Z"
    }
  ]
}
```

### Like Forum Post

```
PUT /forum/:id/like
```

Authentication: Required

Response:
```json
{
  "likes": 1
}
```

## Advanced Features Endpoints

### Recommendations

#### Get Product Recommendations

```
GET /recommendations/products
```

Authentication: Required

Response:
```json
{
  "recommendations": [
    {
      "_id": "60d0fe4f5311236168a109cd",
      "name": "Organic Fertilizer",
      "price": 499,
      "category": "fertilizers",
      "imageUrl": "https://example.com/fertilizer.jpg",
      "rating": 4.5
    }
  ],
  "message": "Recommendations based on your purchase history and preferences"
}
```

#### Get Content Recommendations

```
GET /recommendations/content
```

Authentication: Required

Response:
```json
{
  "message": "Content recommendations would be based on:",
  "factors": [
    "User's bookmarked articles and videos",
    "Content categories user has shown interest in",
    "Popular content in user's preferred language",
    "Seasonal farming content relevant to user's location",
    "New content from sources user has engaged with previously"
  ]
}
```

### Chatbot

#### Get Chatbot Response

```
POST /chatbot/message
```

Authentication: Not required

Request body:
```json
{
  "message": "How can I improve soil health?",
  "language": "english"
}
```

Response:
```json
{
  "response": "Regular soil testing is essential for maintaining optimal soil health. Our Soil Health Tool can provide personalized recommendations for your soil type."
}
```

### QR Code

#### Generate QR Code Data for Product

```
GET /qrcode/product/:id
```

Authentication: Not required

Response:
```json
{
  "success": true,
  "qrData": "{\"id\":\"60d0fe4f5311236168a109cd\",\"name\":\"Organic Fertilizer\",\"price\":499,\"supplier\":\"Agrimart\",\"category\":\"fertilizers\",\"url\":\"https://growsmart.com/product/60d0fe4f5311236168a109cd\"}",
  "productInfo": {
    "id": "60d0fe4f5311236168a109cd",
    "name": "Organic Fertilizer",
    "price": 499,
    "supplier": "Agrimart",
    "category": "fertilizers",
    "url": "https://growsmart.com/product/60d0fe4f5311236168a109cd"
  }
}
```

#### Process Scanned QR Code Data

```
POST /qrcode/scan
```

Authentication: Not required

Request body:
```json
{
  "qrData": "{\"id\":\"60d0fe4f5311236168a109cd\",\"name\":\"Organic Fertilizer\",\"price\":499,\"supplier\":\"Agrimart\",\"category\":\"fertilizers\",\"url\":\"https://growsmart.com/product/60d0fe4f5311236168a109cd\"}"
}
```

Response:
```json
{
  "success": true,
  "message": "QR code scanned successfully",
  "data": {
    "id": "60d0fe4f5311236168a109cd",
    "name": "Organic Fertilizer",
    "price": 499,
    "supplier": "Agrimart",
    "category": "fertilizers",
    "url": "https://growsmart.com/product/60d0fe4f5311236168a109cd"
  }
}
```

### Soil Health

#### Analyze Soil Health

```
POST /soil-health/analyze
```

Authentication: Not required

Request body:
```json
{
  "ph": 6.5,
  "nitrogen": 45,
  "phosphorus": 30,
  "potassium": 200,
  "organicMatter": 3.5,
  "soilType": "loam"
}
```

Response:
```json
{
  "success": true,
  "soilParameters": {
    "ph": 6.5,
    "nitrogen": 45,
    "phosphorus": 30,
    "potassium": 200,
    "organicMatter": 3.5,
    "soilType": "loam"
  },
  "recommendations": {
    "soilHealthScore": 85,
    "soilHealthCategory": "Good",
    "fertilizers": [
      "Balanced NPK fertilizer for maintenance"
    ],
    "coverCrops": [
      "Clover for nitrogen fixation"
    ],
    "practices": [
      "Maintain current soil structure with minimal tillage"
    ],
    "recommendedCrops": [
      "Most crops perform well in loamy soil"
    ]
  }
}
```

### Weather

#### Get Weather Data by Location

```
GET /weather/:location
```

Authentication: Not required

Response:
```json
{
  "location": "Mumbai",
  "temperature": 32,
  "condition": "Partly Cloudy",
  "humidity": 65,
  "windSpeed": 12,
  "forecast": [
    {
      "day": "Today",
      "temp": 32,
      "condition": "Partly Cloudy"
    },
    {
      "day": "Tomorrow",
      "temp": 33,
      "condition": "Sunny"
    }
  ]
}
```

#### Get Weather Forecast

```
GET /weather/forecast/:location
```

Authentication: Not required

Response:
```json
{
  "location": "Delhi",
  "forecast": [
    {
      "date": "2025-04-15",
      "temperature": {
        "min": 24,
        "max": 35
      },
      "condition": "Sunny",
      "humidity": 55,
      "windSpeed": 8,
      "precipitation": 0
    },
    {
      "date": "2025-04-16",
      "temperature": {
        "min": 25,
        "max": 36
      },
      "condition": "Partly Cloudy",
      "humidity": 60,
      "windSpeed": 10,
      "precipitation": 20
    }
  ]
}
```

### Offline

#### Register Device for Offline Access

```
POST /offline/register
```

Authentication: Required

Request body:
```json
{
  "deviceId": "device-123456",
  "phoneNumber": "9876543210"
}
```

Response:
```json
{
  "success": true,
  "message": "Device registered for offline access",
  "offlineFeatures": [
    "Product catalog browsing",
    "Learning resources access",
    "Weather data caching",
    "Order history viewing"
  ],
  "smsAlerts": true
}
```

#### Get Content for Offline Caching

```
GET /offline/content
```

Authentication: Required

Response:
```json
{
  "success": true,
  "lastUpdated": "2025-04-15T10:30:00.000Z",
  "contentToCache": {
    "products": {
      "essential": true,
      "count": 50,
      "sizeEstimate": "2MB",
      "updateFrequency": "daily"
    },
    "articles": {
      "essential": true,
      "count": 20,
      "sizeEstimate": "1MB",
      "updateFrequency": "weekly"
    },
    "videos": {
      "essential": false,
      "count": 5,
      "sizeEstimate": "10MB",
      "updateFrequency": "weekly",
      "note": "Videos are optional for offline caching due to size"
    },
    "weatherData": {
      "essential": true,
      "regions": ["user location + 100km radius"],
      "sizeEstimate": "500KB",
      "updateFrequency": "daily"
    }
  },
  "offlineStrategy": {
    "description": "The app uses a service worker to cache essential content and API responses. When offline, the app serves cached content and queues any user actions for syncing when connectivity is restored.",
    "syncBehavior": "Background sync when connection is available",
    "storageLimit": "50MB maximum for offline content"
  }
}
```

## Error Responses

### Authentication Error

```
Status: 401 Unauthorized
```

```json
{
  "message": "Not authorized, token failed"
}
```

### Not Found Error

```
Status: 404 Not Found
```

```json
{
  "message": "Resource not found"
}
```

### Validation Error

```
Status: 400 Bad Request
```

```json
{
  "message": "Please provide all required fields"
}
```

### Server Error

```
Status: 500 Internal Server Error
```

```json
{
  "message": "Server error"
}
```

## Rate Limiting

The API implements rate limiting to prevent abuse:

- 100 requests per minute for authenticated users
- 30 requests per minute for unauthenticated users

When rate limit is exceeded:

```
Status: 429 Too Many Requests
```

```json
{
  "message": "Rate limit exceeded. Please try again later."
}
```

## Versioning

The current API version is v1. All endpoints should be prefixed with `/api/v1` for future-proofing, although the `/api` prefix is currently sufficient.

## Support

For API support or to report issues, please contact:
- Email: api-support@growsmart.com
- Documentation: https://docs.growsmart.com/api
