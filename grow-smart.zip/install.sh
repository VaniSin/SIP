#!/bin/bash

# Grow Smart Installation Script
# This script sets up the Grow Smart application

echo "=== Grow Smart Installation ==="
echo "Setting up your digital marketplace and learning hub for farmers..."

# Check for required dependencies
echo "Checking dependencies..."

# Check for Node.js
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Please install Node.js v14.0.0 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d 'v' -f 2)
NODE_MAJOR_VERSION=$(echo $NODE_VERSION | cut -d '.' -f 1)
if [ $NODE_MAJOR_VERSION -lt 14 ]; then
    echo "Node.js version $NODE_VERSION is not supported. Please upgrade to v14.0.0 or higher."
    exit 1
fi

# Check for npm
if ! command -v npm &> /dev/null; then
    echo "npm is not installed. Please install npm v6.0.0 or higher."
    exit 1
fi

# Check for MongoDB
echo "Checking MongoDB..."
if ! command -v mongod &> /dev/null; then
    echo "MongoDB is not installed. Would you like to install it? (y/n)"
    read -r install_mongo
    if [ "$install_mongo" = "y" ]; then
        echo "Installing MongoDB..."
        # This is a simplified version - in a real script, we'd have platform-specific installation
        echo "Please visit https://docs.mongodb.com/manual/installation/ for MongoDB installation instructions."
        echo "After installing MongoDB, please run this script again."
        exit 1
    else
        echo "MongoDB is required for Grow Smart. Please install it manually and run this script again."
        exit 1
    fi
fi

# Create .env file for backend
echo "Setting up environment variables..."
if [ ! -f ./backend/.env ]; then
    echo "Creating .env file for backend..."
    cat > ./backend/.env << EOL
PORT=5000
MONGODB_URI=mongodb://localhost:27017/growsmart
JWT_SECRET=$(openssl rand -hex 32)
NODE_ENV=development
EOL
    echo "Environment variables configured."
else
    echo "Backend .env file already exists."
fi

# Install backend dependencies
echo "Installing backend dependencies..."
cd backend
npm install
cd ..

# Install frontend dependencies
echo "Installing frontend dependencies..."
cd frontend
npm install
cd ..

# Setup database
echo "Setting up database..."
cd backend
node << EOL
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('MongoDB connected successfully');
  mongoose.connection.close();
  process.exit(0);
})
.catch(err => {
  console.error('MongoDB connection error:', err);
  process.exit(1);
});
EOL

if [ $? -ne 0 ]; then
    echo "Failed to connect to MongoDB. Please make sure MongoDB is running."
    exit 1
fi

cd ..

# Create startup script
echo "Creating startup script..."
cat > ./start.sh << EOL
#!/bin/bash

# Start MongoDB (if not already running)
if ! pgrep -x "mongod" > /dev/null; then
    echo "Starting MongoDB..."
    mongod --dbpath=/data/db &
    sleep 5
fi

# Start backend server
echo "Starting backend server..."
cd backend
npm start &
BACKEND_PID=\$!

# Wait for backend to start
sleep 5

# Start frontend development server
echo "Starting frontend server..."
cd ../frontend
npm start &
FRONTEND_PID=\$!

# Function to handle script termination
function cleanup {
    echo "Shutting down servers..."
    kill \$FRONTEND_PID
    kill \$BACKEND_PID
    echo "Servers stopped."
    exit 0
}

# Register the cleanup function for script termination
trap cleanup SIGINT SIGTERM

echo "Grow Smart is running!"
echo "- Backend: http://localhost:5000"
echo "- Frontend: http://localhost:3000"
echo "Press Ctrl+C to stop the servers."

# Keep the script running
wait
EOL

chmod +x ./start.sh

echo "Installation complete!"
echo "To start Grow Smart, run: ./start.sh"
echo "Thank you for installing Grow Smart - Digital Marketplace and Learning Hub for Farmers!"
